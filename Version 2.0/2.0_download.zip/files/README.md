# Requirements:
- Python 3
- Pip

# Run:
- Move the Folder to your Favourite location
- Double Click Start.bat
- Or Double Click the "... .exe" file if you downloaded the "..._exe.zip"

# Control
1. Key: A,D
    - Move Left, Right
2. Key: Space
    - Start Beam

# How To Play
- Kill all the ducks with the Beam
- If you kill a Friend you'll get damage
- No Damage = Dead
- No Ducks = Win


